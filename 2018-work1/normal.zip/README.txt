A Pen created at CodePen.io. You can find this one at https://codepen.io/px956678784/pen/mLEdVX.

 first class